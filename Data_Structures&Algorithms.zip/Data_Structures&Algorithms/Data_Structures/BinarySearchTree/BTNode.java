package Data_Structures.BinarySearchTree;

public class BTNode {

    int data;
    BTNode left;
    BTNode right;

    public BTNode(int data){
        this.data = data;
    }
}