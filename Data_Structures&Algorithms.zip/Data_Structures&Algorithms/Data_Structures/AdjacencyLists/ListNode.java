package Data_Structures.AdjacencyLists;

public class ListNode {
    char data;
    ListNode(char data){
         this.data = data;
    }
}
