package Data_Structures.AdjacencyMatrix;

public class MatrixNode {
    char data;
    MatrixNode(char data){
        this.data = data;
    }
}
