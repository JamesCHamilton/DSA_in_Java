package Algorithms.BreadthFirstSearch;

public class BFSNode {
    char data;
    BFSNode(char data){
        this.data = data;
    }
}
