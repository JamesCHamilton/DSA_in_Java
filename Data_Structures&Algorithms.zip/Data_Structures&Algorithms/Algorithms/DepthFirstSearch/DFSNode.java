package Algorithms.DepthFirstSearch;

public class DFSNode {
    char data;
    DFSNode(char data){
        this.data = data;
    }
}
